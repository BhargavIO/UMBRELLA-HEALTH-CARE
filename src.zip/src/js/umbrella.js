$(document).ready(function(){
	$("#login-box").hide();
	$(".login").click(function(){
		$("#login-box").slideToggle(700);
	});
})
